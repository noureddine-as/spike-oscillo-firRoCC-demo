package rocc_regfile

import Chisel._

/* w : width register
 * n : quantity of register (n=35)
 */
class RegisterFile(w: Int, n: Int) extends Module {
  val io = IO(new Bundle {
		// inputs
			val data_in = UInt(INPUT, width = w)
			val done = Bool(INPUT)
			val wr_en = Bool(INPUT)
			val addr = UInt(INPUT, width = w)
			val sel = UInt(INPUT, width = 5) // if coef = 32 used by FIR module
		// outputs
      val enable_fir = Bool(OUTPUT)
			val interrupt_en = Bool(OUTPUT)
			val reg_done = Bool(OUTPUT)
			val data_out = UInt(OUTPUT, width = w)
			val hk = UInt(OUTPUT, width = w)
      val precision = UInt(OUTPUT, width = w)
	})
  // 0 until 31 we have filtre coefs
  val ADDR_PRECISION = 32
	val ADDR_STATUS    = 33
	val ADDR_RESULT    = 34
		
  /* intern Register File */
  //val register_file = Reg(init = Vec(n, UInt(0, width = w))) //Reg Vec doesn't work in RocketChip
  //val register_file = Mem(n, UInt(width = w)) // Mem doesn't work in chisel-template :/
  //val register_file = Reg(Vec(n, Bits(width = w)))
  val register_file = Reg(init = Vec.fill(n){UInt(0,width = w)})
   
  // val mask_regstatus = Wire(UInt(w))
  // mask_regstatus := Cat(UInt(1,width=1),Fill(w-3,UInt(0)),UInt(2,width=2))
  
	when(io.wr_en) {
    when(!io.done) {
		  register_file(io.addr) := io.data_in
	  }
    .otherwise {
      //.elsewhen(io.wr_en && io.done) {
      // result is done then 
      // {done flag is active,enable_fir flag is low,keep others bits}
      // register_file(UInt(33)) := register_file(UInt(33)) & mask_regstatus
      register_file(UInt(33)) := Cat(UInt(1,width=1),register_file(UInt(33))(w-2,1),UInt(0,width=1))
      register_file(UInt(34)) := io.data_in // write result
    }  
  }
	// outputs
  io.enable_fir   := register_file(UInt(33))(0)
	io.reg_done     := register_file(UInt(33))(w-1)
	io.interrupt_en := register_file(UInt(33))(w-1) & register_file(UInt(33))(1)
	io.data_out     := register_file(io.addr)
  io.precision    := register_file(UInt(32))

	io.hk := register_file(io.sel)
}


object RegisterFileMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new RegisterFile(32, 35)))
      // it's necessary w=64 because address request memory is 40 Bits  
      // then, if w=32 the ISA FIR is not respected in str operation
  }
}