package rocc_control

import Chisel._
import control_interface._

class Control(w: Int) extends Module {
  val io = IO(new Bundle {
    val rocc = new RoCCInterface(w)
    val datapath = new DatapathInterface(w)
  })
  /* FSM States */
  val s_idle :: s_wr_result :: s_mv :: s_fifo_put :: s_str :: Nil = Enum(Bits(), 5)

  /* Internal Regs */
  val reg_State = Reg(init = s_idle)
  
  val rs2_data  = Reg(init = UInt(0, w))
  val rs1_data  = Reg(init = UInt(0, w))

  /* FSM */
  when(reg_State === s_idle) {
    // RoCC Interface
    io.rocc.busy := Bool(false)
    // io.rocc.interrupt := Bool(false)

    io.rocc.cmd.ready     := Bool(true)  // control module is ready to receive
    io.rocc.resp.valid    := Bool(false) // always false we don't use rd
    io.rocc.mem.req.valid := Bool(false)
    io.datapath.done      := Bool(false)
    
    // Datapath Interface
    io.datapath.wr_en   := Bool(false)
    io.datapath.wr_fifo := Bool(false)

    // result is done
    when(io.datapath.fir_done) {
      reg_State := s_wr_result
    }
    // save the valid values
    // redundancy in fir_done
    .elsewhen(!(io.datapath.fir_done) && io.rocc.cmd.valid) {
      rs2_data := io.rocc.cmd.rs2
      rs1_data := io.rocc.cmd.rs1
      
      when(io.rocc.cmd.inst.funct === UInt(0)) {
        reg_State := s_mv
      }
      .elsewhen(io.rocc.cmd.inst.funct === UInt(1)) {
        reg_State := s_fifo_put
      }
      .elsewhen(io.rocc.cmd.inst.funct === UInt(2)) {
        reg_State := s_str
      }
      .otherwise {
        reg_State := s_idle
      }
    }
  }
  /* MOVE Operation */
  .elsewhen(reg_State === s_mv) {
    // RoCC Interface
    io.rocc.busy := Bool(true)
    // io.rocc.interrupt := Bool(false)

    io.rocc.cmd.ready     := Bool(false) 
    io.rocc.resp.valid    := Bool(false) 
    io.rocc.mem.req.valid := Bool(false)

    // Datapath Interface
    io.datapath.data_in  := rs1_data // reg_addr[rs2] = rs1
    io.datapath.reg_addr := rs2_data 
    io.datapath.mux_sel  := UInt(1)

    io.datapath.wr_en   := Bool(true)
    io.datapath.wr_fifo := Bool(false)

    reg_State := s_idle
  }
  /* FIFO PUT Operation */
  .elsewhen(reg_State === s_fifo_put) {
    // RoCC Interface
    io.rocc.busy := Bool(true)
    // io.rocc.interrupt := Bool(false)

    io.rocc.cmd.ready     := Bool(false) 
    io.rocc.resp.valid    := Bool(false) 
    io.rocc.mem.req.valid := Bool(false)

    // Datapath Interface
    io.datapath.data_fifo := rs1_data 

    io.datapath.wr_en   := Bool(false)
    io.datapath.wr_fifo := Bool(true)

    reg_State := s_idle
  }
  /* Write result and update done */
  .elsewhen(reg_State === s_str) {
    // RoCC Interface
    io.rocc.busy := Bool(true)
    // io.rocc.interrupt := Bool(false)

    io.rocc.cmd.ready     := Bool(false) 
    io.rocc.resp.valid    := Bool(false) 
    // io.rocc.mem.req.valid := Bool(false)

    // Datapath Interface
    io.datapath.reg_addr   := rs2_data // select data in register
    io.datapath.mux_sel    := UInt(0)  
    io.datapath.done       := Bool(false)

    io.datapath.wr_en   := Bool(false)
    io.datapath.wr_fifo := Bool(false)

    // Memory Interface
    io.rocc.mem.req.addr := rs1_data // addrr
    io.rocc.mem.req.tag  := UInt(0)
    io.rocc.mem.req.cmd  := UInt(1) // M_XWR // perform a load (M_XWR for stores)
    io.rocc.mem.req.typ  := UInt(3) // MT_D // D = 8 bytes, W = 4, H = 2, B = 1
    io.rocc.mem.req.data := io.datapath.data_out
    io.rocc.mem.req.phys := Bool(false)
    io.rocc.mem.invalidate_lr := Bool(false)
    io.rocc.mem.req.valid     := Bool(true)    

    // reg_State := s_exec_mem_req
    when(io.rocc.mem.req.ready) {
      reg_State := s_idle
    }
  }
  .elsewhen(reg_State === s_wr_result) {
    // RoCC Interface
    io.rocc.busy := Bool(true)
    // io.rocc.interrupt := Bool(false)

    io.rocc.cmd.ready     := Bool(false) 
    io.rocc.resp.valid    := Bool(false) 
    // io.rocc.mem.req.valid := Bool(false)

    // Datapath Interface
    io.datapath.reg_addr   := UInt(33)   // select data in register
    io.datapath.mux_sel    := UInt(0)    // takes fir result
    io.datapath.done       := Bool(true) // set bit done in status

    io.datapath.wr_en   := Bool(true)  // enable write register
    io.datapath.wr_fifo := Bool(false)

    reg_State := s_idle
  }
  .otherwise {
    /* Default Values */

    // RoCC Interface
    io.rocc.busy := Bool(true)
    // io.rocc.interrupt := Bool(false)

    io.rocc.cmd.ready     := Bool(false)  // control module is ready to receive
    io.rocc.resp.valid    := Bool(false) // always false we don't use rd
    io.rocc.mem.req.valid := Bool(false)

    // datapath 
    io.datapath.data_in  := UInt(0)
    io.datapath.reg_addr := UInt(0)
    io.datapath.mux_sel  := UInt(0)
    io.datapath.done     := Bool(false)
    io.datapath.data_fifo:= UInt(0)
    
    io.datapath.wr_en   := Bool(false)
    io.datapath.wr_fifo := Bool(false)

    // memory
    io.rocc.mem.req.addr := UInt(0)
    io.rocc.mem.req.tag  := UInt(0)
    io.rocc.mem.req.cmd  := UInt(0)
    io.rocc.mem.req.typ  := UInt(0)
    io.rocc.mem.req.data := UInt(0)
    io.rocc.mem.req.phys := Bool(false)
    io.rocc.mem.invalidate_lr := Bool(false)
    io.rocc.mem.req.valid     := Bool(false)
  }

  // this will be a register
  // this will be active until reset by sw
  io.rocc.interrupt := (io.datapath.reg_done && io.datapath.interrupt_en)
}


object ControlMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new Control(32)))
      // it's necessary w=64 because address request memory is 40 Bits  
      // then, if w=32 the ISA FIR is not respected in str operation
  }
}