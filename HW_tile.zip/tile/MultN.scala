package rocc_fir_multn

import Chisel._

class MultN(w1: Int, w2: Int) extends Module {
	val io = IO(new Bundle {
		val inp1   = SInt(INPUT, width = w1)
		val inp2   = SInt(INPUT, width = w2)
		val mout = SInt(OUTPUT,width = w1+w2)
	})
	io.mout := io.inp1 * io.inp2
}

object MultNMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new MultN(32,32+5)))
  }
}