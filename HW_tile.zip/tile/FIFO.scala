package rocc_fifo

import Chisel._

class FIFO(w: Int, a: Int, n: Int) extends Module {
	val io = IO(new Bundle{
		val wr_fifo = Bool(INPUT)
		val data_in = UInt(INPUT, width = w)
		val sel     = UInt(INPUT, width = a) // a = 5 default
		val x       = UInt(OUTPUT,width = w)
	})
  // fix that:
  // intern signal (d=32 default)
  // regInit to set zero on reset
  //val sample = RegInit(Vec(math.pow(2, a).toInt, UInt(0)))
  val sample = Reg(init = Vec.fill(n){UInt(0,width = w)})
  // val register_file = Reg(Vec(n, Bits(width = w)))
	
  // implementation
	io.x := sample(io.sel)//UInt(io.sel))
  
	when(io.wr_fifo) {
		sample(0) := io.data_in
		for(i <- 1 until sample.length) {
			// printf("i = ")
			// println(i)
			sample(i) := sample(i-1)
		}
	}
}

object FIFOMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new FIFO(32,5,32)))
  }
}

