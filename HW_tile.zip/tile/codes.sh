sublime AdderN.scala .
sublime CompareN.scala .
sublime Control* .
sublime CounterN.scala .
sublime FIFO.scala .
sublime FIR.scala .
sublime MultN.scala .
sublime RegisterFile.scala .
sublime CoprocessorFIR.scala .

# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/AdderN.scala .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/CompareN.scala .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/Control* .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/CounterN.scala .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/FIFO.scala .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/FIR.scala .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/MultN.scala .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/RegisterFile.scala .
# cp /home/gvillanova/Engineering/developer/hw/systemverilog/workspace/rocket-chip/rocc-fir/src/main/scala/CoprocessorFIR.scala .