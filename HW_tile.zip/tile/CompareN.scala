package rocc_fir_comparen

import Chisel._

class CompareN(w: Int) extends Module {
	val io = IO(new Bundle {
		val prec = Bits(INPUT, w)
		val inp1 = Bits(INPUT, w)
		val inp2 = Bits(INPUT, w)
		val compare = Bool(OUTPUT)
	})
  val equal = (io.prec | (~( io.inp1 ^ io.inp2 )))
  
  //io.compare := ( equal === UInt(math.pow(2, w).toInt-1) ) //dont works
  //io.compare := ( equal === Fill(UInt(1),w) ) // this works!
  io.compare := ( equal === Fill(1,UInt(w)) ) // this works!
}

object CompareNMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new CompareN(32)))
  }
}
