package control_interface

import Chisel._

/* Control Interface used */
class DatapathInterface(w: Int) extends Bundle {
 val data_in = UInt(OUTPUT, w)
 val fir_done = Bool(INPUT)
 val wr_en = Bool(OUTPUT)
 val reg_addr = UInt(OUTPUT, w)
 val interrupt_en = Bool(INPUT)
 val reg_done = Bool(INPUT)
 val data_out = UInt(INPUT, w)
 val done = Bool(OUTPUT)
 val mux_sel = Bool(OUTPUT)
 val data_fifo = UInt(OUTPUT, w)
 val wr_fifo = Bool(OUTPUT)
}

/* Rocket Core Interface */
class RoCCInterface(w: Int) extends Bundle {
  val cmd = new Bundle {
    val inst  = new RoCCInstructionAux
    val rs1   = Bits(INPUT, width = w)
    val rs2   = Bits(INPUT, width = w)
    // val status = new MStatus
    val ready = Bool(OUTPUT)
    val valid = Bool(INPUT)
  }
  val resp = new Bundle {
    // val rd    = Bits(OUTPUT, width = 5)
    // val data  = Bits(OUTPUT, width = w)
    val valid = Bool(OUTPUT)
  }
  val mem = new Bundle {
    val req = new Bundle {
      val addr = Bits(OUTPUT, 40)
      val tag  = Bits(OUTPUT, 10)
      val cmd  = Bits(OUTPUT, 5)
      val typ  = Bits(OUTPUT, 3)
      val data = Bits(OUTPUT, w)
      val phys = Bool(OUTPUT)
      val valid = Bool(OUTPUT)
      val ready = Bool(INPUT)
    }
    val resp = Bool(INPUT)
    val invalidate_lr = Bool(OUTPUT)
  }
  val busy = Bool(OUTPUT) 
  val interrupt = Bool(OUTPUT) 
  // val exception = Bool(INPUT) 
}

class RoCCInstructionAux extends Bundle { 
  val funct = Bits(INPUT, width = 7)
  val rs2   = Bits(INPUT, width = 5)
  val rs1   = Bits(INPUT, width = 5)
  // val xd = Bool(INPUT)
  // val xs1 = Bool(INPUT)
  // val xs2 = Bool(INPUT)
  val rd    = Bits(INPUT, width = 5)
  // val opcode = Bits(INPUT, width = 7) 
}


/* 
RoCC Interfaces 
class RoCCInstruction extends Bundle
{
  val funct = Bits(INPUT, width = 7)
  val rs2 = Bits(INPUT, width = 5)
  val rs1 = Bits(INPUT, width = 5)
  val xd = Bool(INPUT)
  val xs1 = Bool(INPUT)
  val xs2 = Bool(INPUT)
  val rd = Bits(INPUT, width = 5)
  val opcode = Bits(INPUT, width = 7)
}

class RoCCCommand(w: Int) extends Bundle {
  val ready = Bool(OUTPUT)
  val valid = Bool(INPUT)
  val inst = new RoCCInstruction
  val rs1 = Bits(INPUT, width = w)
  val rs2 = Bits(INPUT, width = w)
}

class RoCCResponse(w: Int) extends Bundle {
  val ready = Bool(INPUT)
  val valid = Bool(OUTPUT)
  val rd = Bits(OUTPUT, width = 5)
  val data = Bits(OUTPUT, width = w)
}

class RoCCCoreIO(w: Int) extends Bundle {
  val cmd = new RoCCCommand(w)//.flip
  val resp = new RoCCResponse(w)
  val mem = new MemoryIO(w)
  val busy = Bool(OUTPUT) 
  val interrupt = Bool(OUTPUT) 
  val exception = Bool(INPUT) 
}

class MemoryIO(w: Int) extends Bundle {
  val req = new Bundle {
    val ready = Bool(INPUT)
    val valid = Bool(OUTPUT)
    val addr = UInt(OUTPUT, width = 40)
    val tag  = Bits(OUTPUT, width = 10)
    val cmd  = Bits(OUTPUT, 5)
    val typ  = Bits(OUTPUT, 3)
    val phys = Bool(OUTPUT)
    val data = Bits(OUTPUT, w)
  }
  val resp = new Bundle {
    val valid = Bool(INPUT)
    val addr = UInt(INPUT, width = 40)
    val tag  = Bits(INPUT, width = 10)
    val cmd  = Bits(INPUT, 5)
    val typ  = Bits(INPUT, 3)
    val data = Bits(INPUT, w)
  }
}
*/