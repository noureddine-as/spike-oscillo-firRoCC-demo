package rocc_fir_addern

import Chisel._

class AdderN(w: Int) extends Module {
	val io = IO(new Bundle {
		val inp1   = UInt(INPUT, width = w)
		val inp2   = UInt(INPUT, width = w)
		val addout = UInt(OUTPUT,width = w)
	})
	io.addout := io.inp1 + io.inp2
}

object AdderNMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new AdderN(32)))
  }
}