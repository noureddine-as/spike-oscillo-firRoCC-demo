package coprocessor

import Chisel._
import rocc_control._
import control_interface._
import rocc_regfile._
import rocc_fir._
import rocc_fifo._

class CoprocessorFIR(w: Int, a: Int, r: Int) extends Module {
  val io = IO(new Bundle {
    val rocc = new RoCCInterface(w)
  })
  /* Control Module */
  val control = Module(new Control(w))
  io.rocc <> control.io.rocc

  /* FIR Module */
  val fir = Module(new SerialFIR(w,a))
  
  /* Register Module */
  val register_file = Module(new RegisterFile(w, r))

  /* FIFO Module */
  val fifo = Module(new FIFO(w,a, r-3))

  fir.io.precision   := register_file.io.precision
  fir.io.xn          := fifo.io.x
  fir.io.hk          := register_file.io.hk           
  // fir.io.yn (used in MUX)

  // register_file.io.data_in (used in MUX)
  fir.io.enable_rocc       := register_file.io.enable_fir
  register_file.io.done    := control.io.datapath.done
  register_file.io.wr_en   := control.io.datapath.wr_en
  register_file.io.addr    := control.io.datapath.reg_addr
  register_file.io.sel     := fir.io.sel_cnt

  control.io.datapath.fir_done     := fir.io.fir_done
  control.io.datapath.interrupt_en := register_file.io.interrupt_en
  control.io.datapath.reg_done     := register_file.io.reg_done
  control.io.datapath.data_out     := register_file.io.data_out

  fifo.io.wr_fifo := control.io.datapath.wr_fifo
  fifo.io.data_in := control.io.datapath.data_fifo
  fifo.io.sel     := fir.io.sel_cnt

  /* Mux Module */
  register_file.io.data_in := Mux(control.io.datapath.mux_sel,control.io.datapath.data_in,fir.io.yn)
}

object CoprocessorFIRMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new CoprocessorFIR(32,5,35)))
      /* w = 32 (bus)
       * a = 5  (addressing 32 coefs, 2^5)
       * r = 35 (nb of regis)
       */
  }
}