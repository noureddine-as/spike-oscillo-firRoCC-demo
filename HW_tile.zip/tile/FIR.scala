package rocc_fir

import Chisel._
import rocc_fir_addern._
import rocc_fir_comparen._
import rocc_fir_counter._
import rocc_fir_multn._

/* Serial FIR - Top Level Module                   */
/* follow the SerialFIR_opv_v2 VHDL implementation */
/*                                                 */
/* w: architecture (8/16/32/64 default)            */
/* a: map coef                                     */ 
class SerialFIR(w: Int, a: Int) extends Module {
	val io = IO(new Bundle {
		// inputs
		val enable_rocc = Bool(INPUT)

    /* 
      the test of pedro works with w/2
      we'll use w. Why? We can 
    */
		val precision   = UInt(INPUT, width = w) 
		val hk = UInt(INPUT, width = w)
    val xn = UInt(INPUT, width = w)

		// outputs
		val yn = UInt(OUTPUT, width = w)		
		val fir_done = Bool(OUTPUT)
    val sel_cnt = UInt(OUTPUT, width = a) 
    val fir_processing = Bool(OUTPUT)
	})
  io.fir_processing := io.enable_rocc

  val mem_comp = Reg(init = UInt(0, w))
  mem_comp := io.xn

  val compare_n = Module(new CompareN(w))
  compare_n.io.inp1 := io.xn
  compare_n.io.inp2 := mem_comp
  compare_n.io.prec := io.precision

  val counter_n = Module(new CounterN(a))
  counter_n.io.enable_rocc := io.enable_rocc
  io.fir_done := counter_n.io.cntmax
  io.sel_cnt  := counter_n.io.cnt

  // invalid comparation between x[31] and x[0] (pipeline control)
  val next_sample = ~counter_n.io.cnt0 & compare_n.io.compare
  val adder_n = Module(new AdderN(w+a))
  
  //fix that:
  val aux_hk = Wire(UInt(width = w+a))
  when(io.hk(w-1) === UInt(1)) {
    //aux_hk := Cat(Fill(UInt(1),a),io.hk)
    aux_hk := Cat(Fill(1,UInt(a)),io.hk)
  }
  .otherwise {
    aux_hk := io.hk//Cat(Fill(UInt(0),a),io.hk)
  }
  adder_n.io.inp1 := aux_hk

  val mem_coeff = Reg(init = UInt(0, w+a))
  mem_coeff := adder_n.io.addout
  val aux_mux = Mux(next_sample, mem_coeff, UInt(0)) 
  adder_n.io.inp2 := aux_mux

  // clear pipeline stage
  val and_clear_mult0 = (compare_n.io.compare & counter_n.io.cnt1)
  val enable_regs_mem = ~next_sample
  val mem_multh = Reg(init = UInt(0, w+a)) // in*num_coefs
  when(and_clear_mult0) {
    mem_multh := UInt(0)
  }
  .elsewhen(enable_regs_mem) {
    mem_multh := mem_coeff
  }

  val mem_multx = Reg(init = SInt(0, w))
  when(and_clear_mult0) {
    mem_multx := SInt(0)
  }
  .elsewhen(enable_regs_mem) {
    mem_multx := mem_comp.asSInt
  }

  // fix that:
  val mult_n = Module(new MultN(w,w+a))
  mult_n.io.inp1 := mem_multx
  mult_n.io.inp2 := mem_multh.asSInt

  val mem_macc = Reg(init = UInt(0, 2*w+a))
  val adder_n0 = Module(new AdderN(2*w+a))
  adder_n0.io.inp1 := mult_n.io.mout.asUInt
  adder_n0.io.inp2 := mem_macc
  
  when(counter_n.io.cnt1) {
    mem_macc := UInt(0)
  }
  .elsewhen(enable_regs_mem) { 
    // fix that:
    mem_macc := adder_n0.io.addout      
  }
  
  val yn_buffer = Reg(init = UInt(0, w))
  when(counter_n.io.cnt1) {
    yn_buffer := adder_n0.io.addout(2*w+a-1,w+a)
  }
  io.yn := yn_buffer
}

object SerialFIRMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new SerialFIR(32,5)))
  }
}