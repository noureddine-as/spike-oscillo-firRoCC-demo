package rocc_fir_counter

import Chisel._

class CounterN(a: Int) extends Module {
	val io = IO(new Bundle {
		// input
		val enable_rocc = Bool(INPUT)
		// outputs
		val cnt    = UInt(OUTPUT, width = a)
		val cnt0   = Bool(OUTPUT)  
		val cnt1   = Bool(OUTPUT) 
		val cntmax = Bool(OUTPUT) // fir_done
	})
  val aux_cnt0   = Bool()
  val aux_cnt1   = Bool()
  val aux_cntmax = Bool()

	// regs
  val aux_counter = Reg(init = UInt(0, a))

  
  //aux_counter := UInt(0)
  // aux_cnt0    := Bool(false)
  // aux_cnt1    := Bool(false)
  // aux_cntmax  := Bool(false)

	when(io.enable_rocc) {
		aux_counter := aux_counter + UInt(1)
  }
  .otherwise {
    aux_counter := UInt(0)
  }
  
  io.cnt0  := io.enable_rocc && (aux_counter === UInt(0))
  io.cnt1  := io.enable_rocc && (aux_counter === UInt(1))
  io.cntmax:= io.enable_rocc && (aux_counter === UInt(31))
	
  // 	when(aux_counter === UInt(0)) {
	// 		io.cnt0  := Bool(true)
  //      //aux_cnt0  := Bool(true)
	// 	}
	// 	.elsewhen(aux_counter === UInt(1)) {
	// 		io.cnt1  := Bool(true)
  //      //aux_cnt1  := Bool(true)
	// 	}
	// 	.elsewhen(aux_counter === UInt(31)) {//(math.pow(2, a)-1).toUInt ) {//UInt(31)) { // 2^c => 31 default
  //      io.cntmax:= Bool(true)
  //      // aux_cntmax:= Bool(true)
	// 	}
	// }
	// .otherwise {
	// 	aux_counter := UInt(0)
	// 	io.cnt0  := Bool(false)
	// 	io.cnt1  := Bool(false)
	// 	io.cntmax:= Bool(false)
	// }

  // outputs 
  io.cnt    := aux_counter

  // io.cnt0   := aux_cnt0 
  // io.cnt1   := aux_cnt1
  // io.cntmax := aux_cntmax 
}

object CounterNMain {
  def main(args: Array[String]): Unit = {
    chiselMain(Array[String]("--backend", "v", "--targetDir", "generated"),
      () => Module(new CounterN(5)))
  }
}